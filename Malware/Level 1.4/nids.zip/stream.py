import hashlib
from scapy.all import IP, TCP, Raw
import gzip

class Stream:
    def __init__(self, stream_id, alert_fn=None, malware_hashes=None):
        self.stream_id = stream_id
        self.data = b""
        self.alert = alert_fn
        self.known_hashes = malware_hashes or {}
        print(f"[+] Tracking new stream: {self.stream_id}")

    def process_packet(self, packet):
        if Raw in packet:
            self.data += bytes(packet[Raw])

        # Check if TCP FIN or RST flag to end stream
        if packet[TCP].flags & 0x01 or packet[TCP].flags & 0x04:
            print(f"[x] Ending stream {self.stream_id}")
            print(f"Stream data length: {len(self.data)} bytes\n")

            try:
                http_text = self.data.decode(errors='ignore')
                # print(f"HTTP Text: {http_text}")  

                if "HTTP" in http_text or "GET" in http_text or "POST" in http_text:
                    parts = http_text.split("\r\n\r\n", 1)
                    if len(parts) == 2:
                        headers, body = parts
                    else:
                        headers, body = http_text, ""

                    header_lines = headers.split("\r\n")
                    headers_dict = {}
                    for line in header_lines[1:]:
                        if ": " in line:
                            key, value = line.split(": ", 1)
                            headers_dict[key.lower()] = value.lower()
                    # print(f"HTTP Headers: {headers_dict}")

                    encoding = headers_dict.get("accept-encoding", "") # Detect compression

                    body_bytes = body.encode("utf-8", errors="ignore")
                    decompressed_body = body_bytes

                    try:
                        print(f"Encoding detected: {encoding}")
                        if "gzip" in encoding:
                            print("[+] Decompressing gzip-encoded body")
                            decompressed_body = gzip.decompress(body_bytes)
                        else:
                            print("[+] No compression detected or unsupported encoding")
                    except Exception as e:
                        print(f"[-] Error decompressing body: {e}")
                            
                    body_hash = hashlib.sha1(body_bytes).hexdigest()

                    print(f"HTTP Body SHA-1 Hash: {body_hash}")

                    # Check against known malware hashes
                    for malware_name, hashes in self.known_hashes.items():
                        if body_hash in hashes:
                            if self.alert:
                                self.alert(f"Malware detected in HTTP download! Client: {packet[IP].src}; Server: {packet[IP].dst}; Hash: {body_hash} ({malware_name})")

            except Exception as e:
                print(f"Could not decode HTTP data: {e}")

            return True
        return False
