from scapy.all import *
from datetime import datetime, timedelta
import platform
from stream import Stream

# Threat intelligence
# ADD YOUR C2 SERVER IPS HERE
MALICIOUS_IPS = ["4.2.2.2", "virus.com"]

KNOWN_MALWARE_HASHES = {
    "Lokibot": [
        "b3f067e63fff8e171ee26bcde6a6010737c8b22c",
        "73480f2548244fb6a3e9db83a4e74082dd2fa500",
    ],
    "TeslaCrypt": [
        "efbd4555c4b881d77d28f659289373a813e79650",
        "13427e27f405ea2c818d4f55745cd9fb9e336134",
    ],
}

# dict to track alerts
alert_history = {}
# set a timeout to ignore repeated alerts within 10s
REPEATED_ALERT_TIMEOUT = timedelta(seconds=10)

tcp_streams = {}  # Dictionary to track active TCP streams


def get_interface():
    """
    checks for the OS and returns the correct network interface
    """
    print("Checking for OS...")
    if platform.system() == "Windows":
        print("OS is Windows -> VMware Network Adapter VMnet1")
        return "VMware Network Adapter VMnet1"

    elif platform.system() == "Darwin":  # macOS is identified as 'Darwin'
        print("OS is Mac -> vmenet3")
        return "vmenet3"

    else:
        raise RuntimeError("Only supports windows/mac")


def alert(msg):
    """
    alerts function to check if the alert has been logged before within the timeout
    """
    # ignore the alert if it has already been logged before timeout
    if (msg in alert_history) and (
        alert_history[msg] + REPEATED_ALERT_TIMEOUT > datetime.now()
    ):
        return
    # log the alert's msg and timestamp
    alert_history[msg] = datetime.now()
    print(f"*ALERT* {msg}")


def detect_malicious_ip(packet):
    """
    Detection 1.1
    Detect communication with known malicious IPs.
    """
    source_ip = packet[IP].src
    destination_ip = packet[IP].dst

    if destination_ip in MALICIOUS_IPS or source_ip in MALICIOUS_IPS:
        alert(f"Communication between malicious IP {source_ip} and {destination_ip}")


def detectmaliciousdns(packet):
    """
    Detection 1.2
    Detect DNS queries to known malicious domains.
    """
    qname = packet[DNS].qd.qname.decode().rstrip(".")
    source_ip = packet[IP].src

    if qname in MALICIOUS_IPS:
        alert(f"DNS query for malicious domain {qname} from {source_ip}")


def track_tcp_stream(packet):
    """
    Detection 1.3
    Track TCP streams and detect malicious activity.
    """
    if not packet.haslayer(IP) or not packet.haslayer(TCP):
        return  # Skip packets without IP or TCP

    stream_id = (
        packet[IP].src,
        packet[TCP].sport,
        packet[IP].dst,
        packet[TCP].dport,
    )

    if packet[TCP].flags == 0x02:  # SYN packet -> new stream
        if stream_id not in tcp_streams:
            tcp_streams[stream_id] = Stream(
                stream_id, alert_fn=alert, malware_hashes=KNOWN_MALWARE_HASHES
            )

    if stream_id in tcp_streams:
        stream = tcp_streams[stream_id]
        ended = stream.process_packet(packet)

        if ended:
            del tcp_streams[stream_id]


def detect_malicious_traffic(packet):
    """
    function to detect malicious network activity
    """
    try:
        # check if packet is DNS query
        if packet.haslayer(DNS) and packet[DNS].qr == 0:
            detectmaliciousdns(packet)

        # check if the packet has IP layer
        if packet.haslayer(IP):
            detect_malicious_ip(packet)

        # check if the packet has TCP layer
        if packet.haslayer(TCP) and packet.haslayer(IP):
            track_tcp_stream(packet)

    # print any exceptions and continue (to prevent crashing)
    except Exception as e:
        print(f"Error: {e}")


def main():
    print("Starting NIDS!")
    network_interface = get_interface()

    print(f"Sniffing on interface: {network_interface}")
    sniff(prn=detect_malicious_traffic, iface=network_interface)


if __name__ == "__main__":
    main()
