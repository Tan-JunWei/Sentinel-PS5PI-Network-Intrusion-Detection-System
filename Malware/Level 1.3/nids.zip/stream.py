import hashlib
from scapy.all import IP, TCP, Raw

class Stream:
    def __init__(self, stream_id, alert_fn=None, malware_hashes=None):
        self.stream_id = stream_id
        self.data = b""
        self.alert = alert_fn
        self.known_hashes = malware_hashes or {}
        print(f"[+] Tracking new stream: {self.stream_id}")

    def process_packet(self, packet):
        if Raw in packet:
            self.data += bytes(packet[Raw])

        # Check if TCP FIN or RST flag to end stream
        if packet[TCP].flags & 0x01 or packet[TCP].flags & 0x04:
            print(f"[x] Ending stream {self.stream_id}")
            print(f"Stream data length: {len(self.data)} bytes")

            try:
                http_text = self.data.decode(errors='ignore')
                # print(f"HTTP Text: {http_text}")  

                if "HTTP" in http_text or "GET" in http_text or "POST" in http_text:
                    parts = http_text.split("\r\n\r\n", 1)
                    if len(parts) == 2:
                        headers, body = parts
                    else:
                        headers, body = http_text, ""
                    # print(body)
                    body_bytes = body.encode("utf-8", errors="ignore")
                    body_hash = hashlib.sha1(body_bytes).hexdigest()

                    print(f"\nHTTP Body SHA-1 Hash: {body_hash}")

                    # Check against known malware hashes
                    for malware_name, hashes in self.known_hashes.items():
                        if body_hash in hashes:
                            if self.alert:
                                self.alert(f"Malware detected in HTTP download! Client: {packet[IP].src}; Server: {packet[IP].dst}; Hash: {body_hash} ({malware_name})")

            except Exception as e:
                print(f"Could not decode HTTP data: {e}")

            return True
        return False
